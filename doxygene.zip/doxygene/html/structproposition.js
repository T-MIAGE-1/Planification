var structproposition =
[
    [ "boolean", "structproposition.html#aca86c34e89c273d563a98431f23ddd4f", null ],
    [ "nom", "structproposition.html#a47a506e92849c8e081310d145922548f", null ]
];