var annotated_dup =
[
    [ "action", "structaction.html", "structaction" ],
    [ "proposition", "structproposition.html", "structproposition" ],
    [ "s_node", "structs__node.html", "structs__node" ]
];