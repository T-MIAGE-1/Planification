var searchData=
[
  ['boolean',['boolean',['../structproposition.html#aca86c34e89c273d563a98431f23ddd4f',1,'proposition']]]
];
