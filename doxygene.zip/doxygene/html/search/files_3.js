var searchData=
[
  ['proposition_2eh',['proposition.h',['../proposition_8h.html',1,'']]]
];
