var indexSectionsWithContent =
{
  0: "abcflmnpstv",
  1: "aps",
  2: "almp",
  3: "acflmv",
  4: "blnpv",
  5: "n",
  6: "t"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Classes",
  2: "Fichiers",
  3: "Fonctions",
  4: "Variables",
  5: "Définitions de type",
  6: "Macros"
};

