var searchData=
[
  ['proposition',['proposition',['../structproposition.html',1,'']]]
];
